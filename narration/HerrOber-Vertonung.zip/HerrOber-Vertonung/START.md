# Herr Ober! – Übergabepaket für die Vertonung

Beginne mit docs/VERTONUNG_PROMPT.md. Hier liegen die Sprechtexte, Quellen und Prüfwerkzeuge.
Das Paket enthält keine App und keine neu erzeugten Aufnahmen. Python-Abhängigkeit: tools/requirements-narration.txt; zusätzlich ffmpeg/ffprobe.

Du kannst deine Lieferung hier mit tools/narration.py validate prüfen. Zum Einbau verwende tools/narration.py import im vollständigen App-Repository https://github.com/dyslexics/herrober. Ein Import in diese Paketkopie allein aktualisiert keine iOS-App.
